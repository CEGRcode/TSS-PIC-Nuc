#!/usr/bin/env python3
"""
split_tf_phase_windows.py

For each transcription factor (TF), split its TF-Nuc BED entries into four
groups based on strand orientation relative to the nucleosome (same/oppo)
and whether the site's rotational phase falls inside that TF/strand's
"best" phase window (highest skew ratio, from the TSV) or in the
remaining "other" phase window:

    <TF>_Nuc_same_bestWindow.bed
    <TF>_Nuc_same_otherWindow.bed
    <TF>_Nuc_oppo_bestWindow.bed
    <TF>_Nuc_oppo_otherWindow.bed

Inputs
------
1. TF_M1_AdjNuc_annotated.bed
   Tab-separated, no header, 32 columns. Relevant columns (0-based):
     col 6  -> TFBS name                (e.g. "E2F7_M1")
     col 30 -> TFBS phase                (e.g. "phase0" ... "phase9")
     col 31 -> TFBS strand rel. to Nuc   ("same" or "oppo")

2. TFBS_phase_skew_ratios_Nuc.tsv
   Header: TFBS  Strand  Max_Phase_Ratio  Best_Window
   Best_Window is 5 consecutive phases (wrapping mod 10), e.g. "8-9-0-1-2".

3. TF_M1_adjNuc.csv
   Header: Site  TFBS  Distance_Nuc  TFBS_phase  TFBS_strand
   Same TFBS/phase/strand information as the BED file, keyed by Site id
   (used here only as a cross-check / alternate source of truth).

Output
------
Written under OUTDIR (default: ./phase_window_split/), one sub-folder per
TF, each containing the four BED files above, plus a summary TSV
(phase_window_split_summary.tsv) with row counts for every TF x
strand x window combination.
"""

import argparse
import csv
import os
import sys
from collections import defaultdict


def parse_best_window(window_str):
    """'8-9-0-1-2' -> {8,9,0,1,2}"""
    return set(int(x) for x in window_str.strip().split("-"))


def load_best_windows(tsv_path):
    """
    Returns: best_windows[tf][strand] = set_of_phase_ints
    """
    best_windows = defaultdict(dict)
    with open(tsv_path, newline="") as fh:
        reader = csv.DictReader(fh, delimiter="\t")
        for row in reader:
            tf = row["TFBS"].strip()
            strand = row["Strand"].strip().lower()
            window = parse_best_window(row["Best_Window"])
            best_windows[tf][strand] = window
    return best_windows


def extract_phase_int(phase_field):
    """'phase7' -> 7"""
    digits = "".join(ch for ch in phase_field if ch.isdigit())
    return int(digits)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                  formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("bed", help="TF_M1_AdjNuc_annotated.bed")
    ap.add_argument("tsv", help="TFBS_phase_skew_ratios_Nuc.tsv")
    ap.add_argument("csv_file", help="TF_M1_adjNuc.csv")
    ap.add_argument("-o", "--outdir", default="phase_window_split",
                     help="Output directory (default: %(default)s)")
    args = ap.parse_args()

    # 1) Load best-window definitions per TF/strand
    best_windows = load_best_windows(args.tsv)

    # 2) (Sanity check) load the CSV and make sure it's consistent with what
    #    we'll pull from the BED file directly. The BED file already carries
    #    TFBS name / phase / strand in columns 6 / 30 / 31, so it is used as
    #    the primary source for filtering; the CSV is cross-checked by Site.
    # NOTE: Site ids are NOT unique in either file (~192 sites recur, e.g.
    # when overlapping annotations produced more than one row for the same
    # coordinates). The CSV lookup below is therefore only an approximate
    # cross-check; the BED file's own per-row TF/strand/phase columns are
    # always used as the source of truth for splitting.
    csv_lookup = {}
    with open(args.csv_file, newline="") as fh:
        reader = csv.DictReader(fh, delimiter="\t")
        for row in reader:
            csv_lookup[row["Site"]] = (
                row["TFBS"],
                row["TFBS_strand"].strip().lower(),
                extract_phase_int(row["TFBS_phase"]),
            )

    os.makedirs(args.outdir, exist_ok=True)

    # counts[tf][strand][window_label] = n
    counts = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))
    # open file handles lazily, keyed by (tf, strand, window_label)
    handles = {}
    mismatches = 0
    skipped_no_window_def = defaultdict(int)

    def get_handle(tf, strand, window_label):
        key = (tf, strand, window_label)
        if key not in handles:
            tf_dir = os.path.join(args.outdir, tf)
            os.makedirs(tf_dir, exist_ok=True)
            fname = f"{tf}_Nuc_{strand}_{window_label}Window.bed"
            handles[key] = open(os.path.join(tf_dir, fname), "w")
        return handles[key]

    with open(args.bed) as fh:
        for line_no, line in enumerate(fh, 1):
            line = line.rstrip("\n")
            if not line:
                continue
            fields = line.split("\t")
            if len(fields) < 32:
                print(f"WARNING: line {line_no} has {len(fields)} fields, "
                      f"expected >=32 -- skipping", file=sys.stderr)
                continue

            site_id = fields[3]
            tf = fields[6]
            phase = extract_phase_int(fields[30])
            strand = fields[31].strip().lower()

            # cross-check against CSV, if present
            if site_id in csv_lookup:
                csv_tf, csv_strand, csv_phase = csv_lookup[site_id]
                if (csv_tf, csv_strand, csv_phase) != (tf, strand, phase):
                    mismatches += 1

            tf_windows = best_windows.get(tf)
            if not tf_windows or strand not in tf_windows:
                skipped_no_window_def[tf] += 1
                continue

            window_label = "best" if phase in tf_windows[strand] else "other"

            out_fh = get_handle(tf, strand, window_label)
            out_fh.write(line + "\n")
            counts[tf][strand][window_label] += 1

    for h in handles.values():
        h.close()

    # 3) Write summary
    summary_path = os.path.join(args.outdir, "phase_window_split_summary.tsv")
    with open(summary_path, "w", newline="") as fh:
        writer = csv.writer(fh, delimiter="\t")
        writer.writerow(["TF", "Strand", "Window", "N_sites", "Phases_in_window"])
        for tf in sorted(counts):
            for strand in sorted(counts[tf]):
                best_set = best_windows.get(tf, {}).get(strand, set())
                other_set = set(range(10)) - best_set
                for window_label in ("best", "other"):
                    phases = sorted(best_set if window_label == "best" else other_set)
                    n = counts[tf][strand][window_label]
                    writer.writerow([tf, strand, window_label, n,
                                      "-".join(map(str, phases))])

    print(f"Done. Wrote per-TF BED files under: {args.outdir}/<TF>/")
    print(f"Summary table: {summary_path}")
    if mismatches:
        print(f"NOTE: {mismatches} BED lines disagreed with the CSV lookup on "
              f"TF/strand/phase; this is expected since ~192 Site ids are "
              f"duplicated across rows. BED's own per-row values were used.",
              file=sys.stderr)
    if skipped_no_window_def:
        for tf, n in skipped_no_window_def.items():
            print(f"NOTE: {n} lines for TF '{tf}' skipped "
                  f"(no matching Best_Window entry in TSV).", file=sys.stderr)


if __name__ == "__main__":
    main()
